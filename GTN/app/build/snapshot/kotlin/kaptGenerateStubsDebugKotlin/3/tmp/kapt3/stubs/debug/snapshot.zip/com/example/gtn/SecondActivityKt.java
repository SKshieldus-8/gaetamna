package com.example.gtn;

import java.lang.System;

@kotlin.Metadata(mv = {1, 6, 0}, k = 2, d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\u000e\n\u0002\b\u0005\"$\u0010\u0000\u001a\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\u0001X\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010\u0007\u001a\u0004\b\u0003\u0010\u0004\"\u0004\b\u0005\u0010\u0006\"$\u0010\b\u001a\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\u0001X\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010\u0007\u001a\u0004\b\t\u0010\u0004\"\u0004\b\n\u0010\u0006\"$\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\u0001X\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010\u0007\u001a\u0004\b\f\u0010\u0004\"\u0004\b\r\u0010\u0006\"$\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\u0001X\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010\u0007\u001a\u0004\b\u000f\u0010\u0004\"\u0004\b\u0010\u0010\u0006\"$\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\u0001X\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010\u0007\u001a\u0004\b\u0012\u0010\u0004\"\u0004\b\u0013\u0010\u0006\"\u001c\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019\u00a8\u0006\u001a"}, d2 = {"allFiles", "", "Ljava/io/File;", "getAllFiles", "()[Ljava/io/File;", "setAllFiles", "([Ljava/io/File;)V", "[Ljava/io/File;", "idcardFiles", "getIdcardFiles", "setIdcardFiles", "imageFiles", "getImageFiles", "setImageFiles", "licenseFiles", "getLicenseFiles", "setLicenseFiles", "registrationFiles", "getRegistrationFiles", "setRegistrationFiles", "token", "", "getToken", "()Ljava/lang/String;", "setToken", "(Ljava/lang/String;)V", "app_debug"})
public final class SecondActivityKt {
    @org.jetbrains.annotations.Nullable()
    private static java.lang.String token;
    @org.jetbrains.annotations.Nullable()
    private static java.io.File[] imageFiles;
    @org.jetbrains.annotations.Nullable()
    private static java.io.File[] allFiles;
    @org.jetbrains.annotations.Nullable()
    private static java.io.File[] idcardFiles;
    @org.jetbrains.annotations.Nullable()
    private static java.io.File[] licenseFiles;
    @org.jetbrains.annotations.Nullable()
    private static java.io.File[] registrationFiles;
    
    @org.jetbrains.annotations.Nullable()
    public static final java.lang.String getToken() {
        return null;
    }
    
    public static final void setToken(@org.jetbrains.annotations.Nullable()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public static final java.io.File[] getImageFiles() {
        return null;
    }
    
    public static final void setImageFiles(@org.jetbrains.annotations.Nullable()
    java.io.File[] p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public static final java.io.File[] getAllFiles() {
        return null;
    }
    
    public static final void setAllFiles(@org.jetbrains.annotations.Nullable()
    java.io.File[] p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public static final java.io.File[] getIdcardFiles() {
        return null;
    }
    
    public static final void setIdcardFiles(@org.jetbrains.annotations.Nullable()
    java.io.File[] p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public static final java.io.File[] getLicenseFiles() {
        return null;
    }
    
    public static final void setLicenseFiles(@org.jetbrains.annotations.Nullable()
    java.io.File[] p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public static final java.io.File[] getRegistrationFiles() {
        return null;
    }
    
    public static final void setRegistrationFiles(@org.jetbrains.annotations.Nullable()
    java.io.File[] p0) {
    }
}