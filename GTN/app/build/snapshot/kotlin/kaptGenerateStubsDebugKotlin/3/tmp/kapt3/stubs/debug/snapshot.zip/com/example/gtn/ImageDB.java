package com.example.gtn;

import java.lang.System;

@kotlin.Metadata(mv = {1, 6, 0}, k = 1, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0011\b\u0016\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR\u001a\u0010\f\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u0006\"\u0004\b\u000e\u0010\bR\u001e\u0010\u000f\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0006\"\u0004\b\u0011\u0010\bR\u001a\u0010\u0012\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u0006\"\u0004\b\u0014\u0010\b\u00a8\u0006\u0015"}, d2 = {"Lcom/example/gtn/ImageDB;", "Lio/realm/RealmObject;", "()V", "imgName", "", "getImgName", "()Ljava/lang/String;", "setImgName", "(Ljava/lang/String;)V", "imgType", "getImgType", "setImgType", "personalInfo", "getPersonalInfo", "setPersonalInfo", "pk", "getPk", "setPk", "shootingTime", "getShootingTime", "setShootingTime", "app_debug"})
public class ImageDB extends io.realm.RealmObject {
    @org.jetbrains.annotations.NotNull()
    @io.realm.annotations.PrimaryKey()
    private java.lang.String pk = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String imgName = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String imgType = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String personalInfo = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String shootingTime = "";
    
    public ImageDB() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getPk() {
        return null;
    }
    
    public final void setPk(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getImgName() {
        return null;
    }
    
    public final void setImgName(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getImgType() {
        return null;
    }
    
    public final void setImgType(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getPersonalInfo() {
        return null;
    }
    
    public final void setPersonalInfo(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getShootingTime() {
        return null;
    }
    
    public final void setShootingTime(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
}